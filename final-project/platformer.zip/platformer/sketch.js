// character position and velocity
let player = {
    x: 300,
    y: 300,
    vX: 0,
    vY: 0,
    width: 20,
    height: 20,
    jumpHeight: 6,
    isGrounded: false,
    friction:0,
    mass:5
}

let grav = -3;

function setup() {
    const canvasWidth = window.innerWidth;
    const canvasHeight = window.innerHeight; 

    createCanvas(1000, 650);
    // drawGrid(canvasWidth, canvasHeight);
}


function draw() {
    
    frameRate(60);
    clear();

    // if (player.y >= 600) {
    //   player.isGrounded = true;
    if (platforms[0].x <= player.x && player.x <= platforms[0].x + platforms[0].width &&
        platforms[0].y <= player.y && player.y <= platforms[0].y + platforms[0].height) {
            player.isGrounded = true;
    } else {
        player.isGrounded = false;
    }

    if (player.isGrounded == false) {
        player.vY += 0.25;
        
      }

    if(player.isGrounded == true) {
        player.vY = 0;
        player.friction = 0.08;
    }


    if (keyIsDown(LEFT_ARROW) && player.isGrounded) {
        player.vX -= 0.5;
      }
    
    if (keyIsDown(RIGHT_ARROW) && player.isGrounded) {
        player.vX += 0.5
      }

      if (keyIsDown(LEFT_ARROW) && !player.isGrounded) {
        player.vX -= 0.2;
      }
    
    if (keyIsDown(RIGHT_ARROW) && !player.isGrounded) {
        player.vX += 0.2
      }

    if (keyIsDown(UP_ARROW) && player.isGrounded) {
        player.vY = -8;
    }

    if (player.vX > 10) {
        player.vX = 10;
    } 
    if (player.vX < -10) {
        player.vX = -10;
    }
    
    if (!keyIsDown(RIGHT_ARROW) && player.vX > 0  && player.isGrounded) {
        player.vX -= (player.vX * player.friction);
    }

    if (!keyIsDown(LEFT_ARROW) && player.vX < 0 && player.isGrounded) {
        player.vX -= (player.vX * player.friction);
    }


    

    // if (player.vY > 10 || player.vY < -10) {
    //     player.vY = 0;
    // }

     
    
    // player.vX -= player.friction;




    player.x += player.vX ;
    player.y += player.vY;
    
    drawPlayer();
    drawPlat(platforms[0].x,platforms[0].y,platforms[0].width,platforms[0].height);
    drawPlat(platforms[1].x,platforms[1].y,platforms[1].width,platforms[1].height);
    
    
}



let platforms = [
    {   
        x: 0,
        y: 550,
        width: 500,
        height: 100
    },

    {
        x: 500,
        y: 400,
        width: 500,
        height:50
    }

]

function drawPlat(x,y,width,height) {
    strokeWeight(4);
    noFill();
    rect(x,y,width,height);
}

function drawPlayer() {
    fill('red');
    strokeWeight(0);
    rect(player.x + player.width,player.y-player.height,player.width,player.height);
}



// Ignore key looping delay (Done!)
// Make position update every frame (Done!)
// Cap on velocity (Done!)
// Collision: platform[0,1,2]